 
(function (){

  function ParseProxyWeights(proxyWgt) {

    var num = Number(proxyWgt);
    if(isNaN(num))
      num = 100;
    this.proxyWeight = 1+num;

  }

  ParseProxyWeights.prototype.useLegacy = function(){
    // Legacy 
    if(this.proxyWeight === null || this.proxyWeight > 99 )
      return true;
    // Non-Legacy
    if(this.proxyWeight < 2 )
      return false;
    // Non-Legacy is lower, Legacy is higher
    return (Math.floor(Math.random() * 100) < this.proxyWeight );
  }

  // export into the global namespace
  if (typeof exports === "object" && exports) {
    // works for nodejs
    exports.ParseProxyWeights = ParseProxyWeights;
  }
  else {
    // works in rhino
    var globalScope = (function(){ return this; }).call(null);
    globalScope.ParseProxyWeights = ParseProxyWeights;
  }

}());