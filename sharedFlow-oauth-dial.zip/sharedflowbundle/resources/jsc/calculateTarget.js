
function useLegacyTarget(weight) {
    return new ParseProxyWeights(weight).useLegacy();    	
}

var ctConfig = {};

ctConfig.proxyConfig = context.getVariable("weights.proxyweight");
ctConfig.client = context.getVariable("apigee.client_id");
if(ctConfig.proxyConfig !== null){
    if(ctConfig.client !== null){
        ctConfig.proxyWeights = JSON.parse(ctConfig.proxyConfig);
        ctConfig.proxyWeight = ctConfig.proxyWeights['all'];
        if(ctConfig.proxyWeight === null){
            ctConfig.proxyWeight = ctConfig.proxyWeights[ctConfig.client];
        }
        context.setVariable("useLegacy", ""+useLegacyTarget(ctConfig.proxyWeight));
    }else{
        context.setVariable("useLegacy", "true");
        context.setVariable("failedAuth", "true");
    }
}else{
    context.setVariable("useLegacy", "true");
}