var messageURI = context.getVariable("message.uri");
var proxyBase = context.getVariable("proxy.basepath");
var passthroughPathvar = proxyBase;

// add test14 path
var orgEnv = context.getVariable("environment.qualifiedname");
if( orgEnv !== null && orgEnv  == "sbux-integration__oapi-master")
    passthroughPathvar = "test14" + proxyBase;
    
if( proxyBase.indexOf("*") > -1 ){
    
    // Grab the missing piece from the message.uri
    var messageArray = messageURI.split("/");
    var proxyBaseArray = proxyBase.split("/");

    for( var i=0; i<proxyBaseArray.length;i++){
    	if( proxyBaseArray[i] == '*' ){
            passthroughPathvar = passthroughPathvar.replace('*',messageArray[i]);
        }
    }
}

context.setVariable("request.path", passthroughPathvar);
