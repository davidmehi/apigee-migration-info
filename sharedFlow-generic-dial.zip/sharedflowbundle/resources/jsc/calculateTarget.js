
function getDialValue(weight) {
    return new ParseDialWeights(weight).checkDial();    	
}

var dialPercent = context.getVariable("dialPercent");
if(dialPercent !== null)
{
    context.setVariable("dial", ""+getDialValue(dialPercent));
}
else
{
    context.setVariable("dial", false);
}

