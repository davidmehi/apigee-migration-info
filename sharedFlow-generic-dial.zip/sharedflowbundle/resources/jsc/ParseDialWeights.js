 
(function (){

  function ParseDialWeights(dialWgt) {

    var num = Number(dialWgt);
    if(isNaN(num))
      num = 0;
    this.dialWeight = 1+num;

  }

  ParseDialWeights.prototype.checkDial = function(){
    // Set to true 
    if(this.dialWeight === null || this.dialWeight > 99 )
      return true;
    // Set to false
    if(this.dialWeight < 2 )
      return false;
    // Non-Legacy is lower, Legacy is higher
    return (Math.floor(Math.random() * 100) < this.dialWeight );
  }

  // export into the global namespace
  if (typeof exports === "object" && exports) {
    // works for nodejs
    exports.ParseDialWeights = ParseDialWeights;
  }
  else {
    // works in rhino
    var globalScope = (function(){ return this; }).call(null);
    globalScope.ParseDialWeights = ParseDialWeights;
  }

}());  
(function (){

  function ParseDialWeights(dialWgt) {

    var num = Number(dialWgt);
    if(isNaN(num))
      num = 0;
    this.dialWeight = 1+num;

  }

  ParseDialWeights.prototype.checkDial = function(){
    // Set to true 
    if(this.dialWeight === null || this.dialWeight > 99 )
      return true;
    // Set to false
    if(this.dialWeight < 2 )
      return false;
    // Non-Legacy is lower, Legacy is higher
    return (Math.floor(Math.random() * 100) < this.dialWeight );
  }

  // export into the global namespace
  if (typeof exports === "object" && exports) {
    // works for nodejs
    exports.ParseDialWeights = ParseDialWeights;
  }
  else {
    // works in rhino
    var globalScope = (function(){ return this; }).call(null);
    globalScope.ParseDialWeights = ParseDialWeights;
  }

}());